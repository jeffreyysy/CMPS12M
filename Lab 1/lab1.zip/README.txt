Jeffrey Yeung
jeyyeung
CMPS 12M
January 13, 2018
files being submitted

1. README.txt
2. Makefile
3. HelloUser.java
4. HelloUser2.java
