//Jeffrey Yeung
//jeyyeung
//CMPS 12M
//January 13, 2018
//Program prints a simple line.

public class HelloUser2 {
	public static void main(String[] args) {
		System.out.println("Hi Professor Adams");
	}
}
