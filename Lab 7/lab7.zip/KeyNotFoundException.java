//-----------------------------------------------------------------------------
// KeyNotFoundException.java
//-----------------------------------------------------------------------------

public class KeyNotFoundException extends RuntimeException{
   public KeyNotFoundException(String s){ super(s);}
}
