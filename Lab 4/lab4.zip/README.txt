Jeffrey Yeung
jeyyeung
CMPS 12M
February 10, 2018
read me file

1. charType.c
2. Makefile
3. README.txt
