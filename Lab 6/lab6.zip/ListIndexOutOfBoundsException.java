//-----------------------------------------------------------------------------
// ListIndexOutOfBoundsException.java
//-----------------------------------------------------------------------------

@SuppressWarnings("serial")
public class ListIndexOutOfBoundsException extends IndexOutOfBoundsException{
   public ListIndexOutOfBoundsException(String s){
      super(s);
   }
}
